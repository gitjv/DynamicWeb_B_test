﻿﻿// Gramps - a GTK+/GNOME based genealogy program
//
// Copyright (C) 2021 John Vitlin
//
// This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.
// This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
// You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
//
// functions for Dynamic Web B modifications
//


function clickCounter() {
    alert("Hello! I am the clickCounter alert box!");
    if (typeof (Storage) !== "undefined") {
        if (localStorage.clickcount) {
            localStorage.clickcount = Number(localStorage.clickcount) + 1;
        } else {
            localStorage.clickcount = 1;
        }
        document.getElementById("result").innerHTML = "You have clicked the button " + localStorage.clickcount + " time(s).";
    } else {
        document.getElementById("result").innerHTML = "Sorry, your browser does not support web storage...";
    }
}



function lifespan_clicked() {
    // alert("lifespan new new clicked");
    // can just redo the vital calls, as they handle lifespan limit
    vital_clicked("child");
    vital_clicked("spouse");
    vital_clicked("sibling");
    vital_clicked("parent");
}


function vital_clicked(kind) {
    // alert("'vital__clicked' " + kind + " state is " + $("#vital_" + kind).is(':checked') + " and Lifespan state is " + $("#lifespan").is(':checked'));
    var v_checked = $("#vital_" + kind).is(':checked');
    var ls_limit_checked = $("#lifespan").is(':checked');
    // alert("'vital__clicked' " + kind + " state is " + v_checked + " and Lifespan state is " + ls_limit_checked);
    var self = this;
    if (v_checked) {  //show or hide vitals depending on lifespan
        // alert ("vital true part");
        if (ls_limit_checked) {
            // row is vital and age in lifesp is true  - show
            var $rowsN = $("#extended_events tbody tr").filter(function () {
                return $.trim($(this).find("td").eq(2).text()) === kind && $.trim($(this).find("td").eq(1).text()) === "true";
            }).show();
            // row is vital and age in lifspan is not true - hide
            var $rowsN = $("#extended_events tbody tr").filter(function () {
                return $.trim($(this).find("td").eq(2).text()) === kind && $.trim($(this).find("td").eq(1).text()) !== "true";
            }).hide();
        } else {  // ls not limited
            // row is vital and in lifesp is true - show
            // row is vital and in lifsp is not true - show
            var $rowsN = $("#extended_events tbody tr").filter(function () {
                return $.trim($(this).find("td").eq(2).text()) === kind;
            }).show();
        }
    } else { //vital kind check is false, hide any vital kinds regardless of lifespan
        //alert("vital false part");
        var $rowsN = $("#extended_events tbody tr").filter(function () {
            return $.trim($(this).find("td").eq(2).text()) === kind;
        }).hide();
    }
}


//<script>
var formValues = JSON.parse(localStorage.getItem('formValues')) || {};
var $checkboxes = $("#checkbox-container :checkbox");

// function allChecked(){
//  return $checkboxes.length === $checkboxes.filter(":checked").length;
// }
// function updateButtonStatus(){
//   $button.text(allChecked()? "Uncheck all" : "Check all");
// }
// function handleButtonClick(){
//   $checkboxes.prop("checked", allChecked()? false : true)
// }
function updateStorage() {
    alert("update storage fn");
    $checkboxes.each(function () {
        alert("'update storage each' alert");
        formValues[this.id] = this.checked;
    });

    // formValues["buttonText"] = $button.text();
    localStorage.setItem("formValues", JSON.stringify(formValues));
}

// $button.on("click", function() {
//   handleButtonClick();
//   updateButtonStatus();
//   updateStorage();
// });

// $checkboxes.on("change", function(){
$checkboxes.on("change", function () {
    // updateButtonStatus();
    alert("check box onchange alert");
    updateStorage();
});


// JV make a function to try understand on load...
function check_values_load() {
    alert("  check values load  fn , alert box!");
}

alert(" 'page loading maybe' fn alert box!");
// On page load
$.each(formValues, function (key, value) {
    alert("  in dwr b ext eachfn " + key + " alert box!");
    $("#" + key).prop("checked", value);
});

// $button.text(formValues["buttonText"]);
